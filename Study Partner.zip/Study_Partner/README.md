# Study_Partner
One stop solution for organizing and maintaining notes and attendance

Before committing read the following:

1. Id for each screen should be preceded by the activity name using camelCase.
2. Tabs should be used.
3. Each file should go under proper package name.
4. Name of each file should start with the activity it is associated with.
