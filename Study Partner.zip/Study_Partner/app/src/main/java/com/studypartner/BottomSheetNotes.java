package com.studypartner;

class BottomSheetNotes extends android.support.design.widget.BottomSheetFragment {
}
